# README #

This software remotely captures images from the camera.You can do GPIO control with WebSocket connection.
In addition, gate.py file was created in the door opening and closing.

.................................................. .................................................. ..................................

modules required for installation:
vlc, pygame, tornado, pad4pi
on the terminal to perform: pip install module_name

the most important hardware for raspberry pi 3, keypad 4x3, 2 servo motors, usb camera
connect a speaker to get sound. Make sure you have the correct GPIO connections.

.................................................. .................................................. ................................

to run sudo python python_name.py
It is offered for your use. You can develop this project.Then you open 127.0.0.1