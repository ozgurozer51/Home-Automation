from pad4pi import rpi_gpio
import time
import vlc
import RPi.GPIO as GPIO



GPIO.setmode(GPIO.BCM)
GPIO.setup(18, GPIO.OUT)



KEYPAD = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
    ["*", 0, "#"]
]
ROW_PINS = [23, 24, 16, 20]
COL_PINS = [21, 26, 22]
factory = rpi_gpio.KeypadFactory()
keypad = factory.create_keypad(keypad=KEYPAD, row_pins=ROW_PINS, col_pins=COL_PINS)


x=['0','0','0','0']
p= [1,2,3,4]

j=0
i=0
z=4
w=0
def printKey(k):
    global j,i,z,w,p,x,m
    global m
    print(k)
    if (4==(2+2)):
        c = vlc.MediaPlayer("/home/pi/Desktop/gate/blip1.wav")
        c.play()
        x[i]=k
        i+=1
        print(x)
        print(p)
    if (x==p):
        x=['0','0','0','0']
        i=0
        j=0
        pwm = GPIO.PWM(18,50)
        pwm.start(40)
        pwm.ChangeDutyCycle(1)
        time.sleep(4)
        pwm.ChangeDutyCycle(40)
        time.sleep(3)
    if (x!=p and i==4):
        c1 = vlc.MediaPlayer("/home/pi/Desktop/gate/123.wav")
        c1.play()
        x=['0','0','0','0']
        i=0
        j+=1
    if (j==3):
        j=0
        rt = vlc.MediaPlayer("/home/pi/Desktop/gate/alarm.mp3")
        rt.play()
        time.sleep(4.7)
        rt = vlc.MediaPlayer("/home/pi/Desktop/gate/alarm.mp3")
        rt.play()
        time.sleep(4.7)
        rt = vlc.MediaPlayer("/home/pi/Desktop/gate/alarm.mp3")
        rt.play()
        time.sleep(4.7)
        rt = vlc.MediaPlayer("/home/pi/Desktop/gate/alarm.mp3")
        rt.play()



keypad.registerKeyPressHandler(printKey)


time.sleep(100000)
keypad.cleanup()

global pwm
pwm.stop()
GPIO.cleanup()




