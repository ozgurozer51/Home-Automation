import os.path
import tornado.httpserver
import tornado.web
import RPi.GPIO as GPIO
import time
import argparse
import os
import io
import tornado.ioloop
import tornado.websocket
from PIL import Image
import pygame.camera
import pygame.image
import pygame, sys, os
from pygame.locals import *


GPIO.setmode(GPIO.BCM)

i=15

settings = dict(
	template_path = os.path.join(os.path.dirname(__file__), "static"),
	static_path = os.path.join(os.path.dirname(__file__), "static")
	)


class MainHandler(tornado.web.RequestHandler):
  def get(self):
     print "[HTTP](MainHandler) User Connected."
     self.render("index.html")

	
class WSHandler(tornado.websocket.WebSocketHandler):
  def open(self):
    print '[WS] Connection was opened.'
    
  def on_message(self, message):
    print '[WS] Incoming message:', message
    if message == "on_g":
      GPIO.setup(13, GPIO.OUT)
      GPIO.output(13, True)
    if message == "off_g":
      GPIO.output(13, False)
    if message == "on_r":
      GPIO.setup(11, GPIO.OUT)
      GPIO.output(11, True)
    if message == "off_r":
      GPIO.output(11, False)
      
    if message == "left":
      global i
      if (i<19):
         i+=1
         GPIO.setup(12, GPIO.OUT)
         pwm = GPIO.PWM(12, 100)
         pwm.start(i-1)
         pwm.ChangeDutyCycle(i)
         time.sleep(0.5)
      
    if message == "right":  
      global i
      if (i>5):
         i-=1
         GPIO.setup(12, GPIO.OUT)
         pwm = GPIO.PWM(12, 100)
         pwm.start(i+1) 
         pwm.ChangeDutyCycle(i)
         time.sleep(0.5)
      
      
  def on_close(self):
    print '[WS] Connection was closed.'




parser = argparse.ArgumentParser(description='Start the PyImageStream server.')

parser.add_argument('--port', default=80, type=int)
parser.add_argument('--camera', default=0, type=int)
parser.add_argument('--width', default=640, type=int)
parser.add_argument('--height', default=480, type=int)
parser.add_argument('--quality', default=70, type=int)
parser.add_argument('--stopdelay', default=7, type=int)

args = parser.parse_args()

class Camera:

    def __init__(self, index, width, height, quality, stopdelay):
        print("Initializing camera...")
        pygame.camera.init()
        camera_name = pygame.camera.list_cameras()[index]
        self._cam = pygame.camera.Camera(camera_name, (width, height))
        print("Camera initialized")
        self.is_started = False
        self.stop_requested = False
        self.quality = quality
        self.stopdelay = stopdelay

    def request_start(self):
        if self.stop_requested:
            print("Camera continues to be in use")
            self.stop_requested = False
        if not self.is_started:
            self._start()

    def request_stop(self):
        if self.is_started and not self.stop_requested:
            self.stop_requested = True
            tornado.ioloop.IOLoop.current().call_later(self.stopdelay, self._stop)

    def _start(self):
        print("Starting camera...")
        self._cam.start()
        print("Camera started")
        self.is_started = True

  
    def _stop(self):
        if self.stop_requested:
            print("Stopping camera now...")
            self._cam.stop()
            print("Camera stopped...")
            self.is_started = False
            self.stop_requested = False

    def get_jpeg_image_bytes(self):
        img = self._cam.get_image()
      
        
        imgstr = pygame.image.tostring(img, "RGB", False)
        pimg = Image.frombytes("RGB", img.get_size(), imgstr)
  
        with io.BytesIO() as bytesIO:
            pimg.save(bytesIO, "JPEG", quality=self.quality, optimize=True)
            return bytesIO.getvalue()


camera = Camera(args.camera, args.width, args.height, args.quality, args.stopdelay)


class ImageWebSocket(tornado.websocket.WebSocketHandler):
    clients = set()

    def check_origin(self, origin):       
        return True

    def open(self):
        ImageWebSocket.clients.add(self)
        print("WebSocket opened from: " + self.request.remote_ip)
        camera.request_start()

    def on_message(self, message):
        jpeg_bytes = camera.get_jpeg_image_bytes()
        self.write_message(jpeg_bytes, binary=True)

    def on_close(self):
        ImageWebSocket.clients.remove(self)
        print("WebSocket closed from: " + self.request.remote_ip)
        if len(ImageWebSocket.clients) == 0:
            camera.request_stop()

script_path = os.path.dirname(os.path.realpath(__file__))
static_path = script_path + '/static/'

app = tornado.web.Application([
        (r"/websocket", ImageWebSocket),
        (r'/', MainHandler),
        (r'/ws', WSHandler),
        (r"/(.*)", tornado.web.StaticFileHandler, {'path': static_path, 'default_filename': 'index.html'}),        
    ],**settings)

if __name__ == "__main__":
    try:
        http_server = tornado.httpserver.HTTPServer(app)
        http_server.listen(80)
        main_loop = tornado.ioloop.IOLoop.instance()
        tornado.ioloop.IOLoop.current().start()

        print "Tornado Server started "
        main_loop.start()

    except:
        print "Exception  - Tornado Server stopped."
        GPIO.cleanup()








